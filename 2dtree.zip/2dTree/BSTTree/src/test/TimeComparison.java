package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import tree.bst.BinarySearchTree;

public class TimeComparison {

    public static void main(String[] args) {
	
	
	System.out.println("\nBeginning massive integer BST");
	BinarySearchTree<Integer> intBst = new BinarySearchTree<>();
	
	ArrayList<Integer> intList = new ArrayList<>();
	
	System.out.println("Adding random numbers to array list.");
	for(int i = 0; i < 1_000_000; i++) {
	    intList.add((int)(Math.random() * 100_000_001));
	}
	
	System.out.println("\nBuilding balanced search tree from random array list.");
	buildBalancedTree(intBst, intList.toArray());
	System.out.println("Done building.");
	System.out.println("Balanced Binary Search Tree Size: " + intBst.getSize());
	System.out.println("Balanced Binary Search Tree Height: " + intBst.getHeight());
	long timeStart = System.currentTimeMillis();
	for(int i = 0; i < 1_000_000; i++) {
	    intBst.contains(i);
	}
	long timeEnd = System.currentTimeMillis() - timeStart;
	System.out.println("Balanced Binary Search Tree Time: " + (timeEnd * .001));
	
	intBst.clear();
	
	System.out.println("\nBuilding binary search tree from random array list");
	for(Integer elem : intList) {
	    intBst.add(elem);
	}
	System.out.println("Done building.");


	System.out.println("Random Binary Search Tree Size: " + intBst.getSize());
	System.out.println("Random Binary Search Tree Height: " + intBst.getHeight());
	
	timeStart = System.currentTimeMillis();
	for(int i = 0; i < 1_000_000; i++) {
	    intBst.contains(i);
	}
	timeEnd = System.currentTimeMillis() - timeStart;
	System.out.println("Random Binary Search Tree Time: " + (timeEnd * .001));
	
	intBst.clear();
	
	System.out.println("\nSorting the random array list");
	Collections.sort(intList);

	System.out.println("Building binary search tree from sorted array list");
	for(Integer elem : intList) {
	    intBst.add(elem);
	}
	System.out.println("Done building.");

	System.out.println("Biased Right Binary Search Tree Size: " + intBst.getSize());
	System.out.println("Biased Right Binary Search Tree Height: " + intBst.getHeight());
	
	timeStart = System.currentTimeMillis();
	for(int i = 0; i < 1_000_000; i++) {
	    intBst.contains((int)(Math.random() * 100_000_001));
	}
	timeEnd = System.currentTimeMillis() - timeStart;
	System.out.println("Biased Right Binary Search Tree Time: " + (timeEnd * .001));
	
    }
    
    private static void buildBalancedTree(BinarySearchTree bst, Object arr[]) {
	Arrays.sort(arr);
	buildBalancedTree(bst, arr, 0, arr.length - 1);
    }
    
    private static void buildBalancedTree(BinarySearchTree bst, Object arr[], int low, int high) {
	if(low > high) {
	    return;
	}
	
	int mid = (low + high) / 2;
	
	bst.add((Comparable)arr[mid]);
	
	buildBalancedTree(bst, arr, low, mid - 1);
	buildBalancedTree(bst, arr, mid + 1, high);
    }

}
