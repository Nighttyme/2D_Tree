package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import tree.bst.BinarySearchTree;

public class BasicOperationTests {

    public static void main(String[] args) {

	BinarySearchTree<String> bst = new BinarySearchTree<>();
	
	List<String> alphabet= new ArrayList<String>();
	
	for(char c = 'A'; c <= 'Z'; c+=2) {
	    alphabet.add("" + c);
	}
	
	buildBalancedTree(bst, alphabet);
	bst.inorder();
	
	System.out.println(bst);
	System.out.println(bst.getHeight());
	
	System.out.println("\n|\t\t\t\tTesting contains True");
	System.out.println("|" + bst.contains("K"));
	
	System.out.println("\n|\t\t\t\tTesting contains True");
	System.out.println("|" + bst.contains("W"));
	
	System.out.println("\n|\t\t\t\tTesting contains False");
	System.out.println("|" + bst.contains("P"));
	
	System.out.println("\n|\t\t\t\tTesting contains False");
	System.out.println("|" + bst.contains("B"));
	
	System.out.println("\n|\t\t\t\tTesting GetMin");
	System.out.println("|" + bst.getMin());
	
	System.out.println("\n|\t\t\t\tTesting GetMax");
	System.out.println("|" + bst.getMax());
	
	System.out.println("\n|\t\t\tTesting Remove Method Leaf(Q)");
	bst.remove("Q");
	System.out.println("|" + bst);
	
	System.out.println("|\n|Rebuilding.");
	bst.add("Q");
	
	System.out.println("\n|\t\t\tTesting Remove Method Leaf(G)");
	bst.remove("G");
	System.out.println("|" + bst);
	
	System.out.println("|\n|Rebuilding.");
	bst.add("G");

	System.out.println("\n|\t\tTesting Remove Method Node with Left Child(W) \n|\tNOTE: Y was removed first to make a node with left child");
	bst.remove("Y");
	bst.remove("W");
	System.out.println("|" + bst);
	
	System.out.println("|\n|Rebuilding.");
	bst.clear();
	buildBalancedTree(bst, alphabet);
	
	System.out.println("|" + bst);
	
	System.out.println("\n|\t\tTesting Remove Method Node with Right Child(A)");
	bst.remove("A");
	System.out.println("|" + bst);
	
	System.out.println("|\n|Rebuilding.");
	bst.clear();
	buildBalancedTree(bst, alphabet);
	
	System.out.println("|" + bst);
	
	System.out.println("\n|\tTesting Remove Method Node with both Right and Left Child(S)");
	bst.remove("S");
	System.out.println("|" + bst);
	
	System.out.println("|\n|Rebuilding.");
	bst.clear();
	buildBalancedTree(bst, alphabet);
	
	
	System.out.println("|" + bst);
    }
    
    private static void buildBalancedTree(BinarySearchTree bst, List objs) {
	Collections.sort(objs);
	buildBalancedTree(bst, objs, 0, objs.size() - 1);
    }
    
    private static void buildBalancedTree(BinarySearchTree bst, List objs, int low, int high) {
	if(low > high) {
	    return;
	}
	
	int mid = (low + high) / 2;
	
	bst.add((Comparable)objs.get(mid));
	
	buildBalancedTree(bst, objs, low, mid - 1);
	buildBalancedTree(bst, objs, mid + 1, high);
    }

}
