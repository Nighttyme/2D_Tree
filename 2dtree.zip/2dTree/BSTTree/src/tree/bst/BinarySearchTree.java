package tree.bst;

import java.util.LinkedList;
import java.util.Queue;

public class BinarySearchTree<T extends Comparable<? super T>> {

	private Node<T> root;
	private int size;

	public BinarySearchTree() {
		clear();
	}

	/************ LAB ZONE **************************/

	public boolean add(T newItem) {
		if (isEmpty()) {
			root = new Node<>(newItem);
		} else {
			Node<T> parent = null;
			Node<T> temp = root;
			while (temp != null) {
				int result = newItem.compareTo(temp.data);
				if (result < 0) {
					parent = temp;
					temp = temp.left;
				} else if (result > 0) {
					parent = temp;
					temp = temp.right;
				} else {
					return false;
				}
			}
			Node<T> newNode = new Node<>(newItem);
			int result = newItem.compareTo(parent.data);
			if (result < 0) {
				parent.left = newNode;
			} else {
				parent.right = newNode;
			}
		}
		size += 1;
		return true;
	}

	public boolean remove(T itemToRemove) {
		if (isEmpty()) {
			return false;
		} else {
			Node<T> parent = null;
			Node<T> temp = root;
			while (temp != null) {
				int result = itemToRemove.compareTo(temp.data);
				if (result < 0) {
					parent = temp;
					temp = temp.left;
				} else if (result > 0) {
					parent = temp;
					temp = temp.right;
				} else {
					removeNode(parent, temp);
					break;
				}
			}
			if (temp == null) {
				return false;
			} else {
				size -= 1;
				return true;
			}
		}
	}

	private void removeNode(Node<T> parent, Node<T> nodeToRemove) {
		if (nodeToRemove.left == null && nodeToRemove.right == null) {
			removeLeafNode(parent, nodeToRemove);
		} else if (nodeToRemove.left != null && nodeToRemove.right == null) {
			removeNodeWithLeftChild(parent, nodeToRemove);
		} else if (nodeToRemove.left == null && nodeToRemove.right != null) {
			removeNodeWithRightChild(parent, nodeToRemove);
		} else {
			removeNodeWithBothChild(parent, nodeToRemove);
		}
	}

	private void removeLeafNode(Node<T> parent, Node<T> nodeToRemove) {
		if (parent.left == nodeToRemove) {
			parent.left = null;
		} else {
			parent.right = null;
		}
	}

	private void removeNodeWithLeftChild(Node<T> parent, Node<T> nodeToRemove) {
		if (parent.left == nodeToRemove) {
			parent.left = nodeToRemove.left;
			nodeToRemove.left = null;
		} else {
			parent.right = nodeToRemove.left;
		}
	}

	private void removeNodeWithRightChild(Node<T> parent, Node<T> nodeToRemove) {
		if (parent.left == nodeToRemove) {
			parent.left = nodeToRemove.right;
			nodeToRemove.left = null;
		} else {
			parent.right = nodeToRemove.right;
		}
	}

	private void removeNodeWithBothChild(Node<T> parent, Node<T> nodeToRemove) {
		Node<T> temp = nodeToRemove.right;
		while (temp.left != null) {
			parent = temp;
			temp = temp.left;
		}
		nodeToRemove.data = temp.data;
		removeNode(parent, temp);
	}

	public boolean contains(T itemToFind) {
		if (isEmpty()) {
			return false;
		} else {
			Node<T> parent = null;
			Node<T> temp = root;
			while (temp != null) {
				int result = itemToFind.compareTo(temp.data);
				if (result < 0) {
					temp = temp.left;
				} else if (result > 0) {
					temp = temp.right;
				} else {
					return true;
				}
			}
		}
		return false;
	}

	public T getMin() {
		if (isEmpty()) {
			return null;
		} else {
			Node<T> temp = root;
			while (temp.left != null) {
				temp = temp.left;
			}
			return temp.data;
		}
	}

	public T getMax() {
		if (isEmpty()) {
			return null;
		} else {
			Node<T> temp = root;
			while (temp.right != null) {
				temp = temp.right;
			}
			return temp.data;
		}
	}
	
public void inorder() {
print(root);
reverseprint(root);
}
	private void print( Node<T> temp) {
		if (temp.left != null) {
		print(temp.left); 
		}
		System.out.println(temp.data);
		if (temp.right != null) {
			print(temp.right);
		}
	}

	private void reverseprint(Node<T> temp) {
		if (temp.right != null) {
			reverseprint(temp.right);
		}
		System.out.println(temp.data);
		if (temp.left != null) {
			reverseprint(temp.left); 
			}
	}

	/***********************************************/

	public int getHeight() {
		if (isEmpty()) {
			return -1;
		}
		Queue<Node<T>> q = new LinkedList<>();
		int height = -1;

		q.add(root);
		while (!q.isEmpty()) {
			height += 1;
			int nodes = q.size();
			while (nodes > 0) {
				Node<T> current = q.remove();
				if (current.left != null) {
					q.add(current.left);
				}

				if (current.right != null) {
					q.add(current.right);
				}

				nodes--;
			}
		}
		return height;
	}

//    public int getHeight() {
//	return getHeight(root, -1);
//    }
//    
//    private int getHeight(Node<T> current, int height) {
//	if(current == null) {
//	    return height;
//	}
//	
//	return Math.max(getHeight(current.left, height+1), getHeight(current.right, height+1));
//    }

	public boolean isEmpty() {
		return size == 0;
	}

	public int getSize() {
		return size;
	}

	public void clear() {
		root = null;
		size = 0;
		System.gc();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		buildLevelOrderString(sb);
		sb.append("]");
		return sb.toString();
	}

	private void buildLevelOrderString(StringBuilder sb) {
		if (isEmpty()) {
			return;
		}

		Queue<Node<T>> q = new LinkedList<>();
		q.add(root);

		Node<T> temp;
		while (!q.isEmpty()) {
			temp = q.remove();

			if (temp.left != null) {
				q.add(temp.left);
			}

			if (temp.right != null) {
				q.add(temp.right);
			}

			sb.append(temp.data);

			if (!q.isEmpty()) {
				sb.append(", ");
			}
		}
	}

	private class Node<E> {
		private Node<E> left;
		private Node<E> right;
		private E data;

		public Node(E data) {
			this.data = data;
		}
	}
}
