
public class Point2D {

    public final int x;
    public final int y;
    
    public Point2D(int x, int y) {
	this.x = x;
	this.y = y;
    }
    
    @Override
    public String toString() {
	return String.format("(%d, %d)", x, y);
    }
    
    @Override
    public boolean equals(Object obj) {
	if(obj == null) {
	    return false;
	}
	if(!(obj instanceof Point2D)) {
	    return false;
	}
	if(this == obj) {
	    return true;
	}
	Point2D other = (Point2D) obj;
	return this.x == other.x && this.y == other.y;
    }
}