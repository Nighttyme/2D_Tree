package kdTree;

import java.util.LinkedList;

import BinarySearchTree.Node;

public class TwoDTree {

    private TwoDTreeNode root;
    private int size;

    public TwoDTree() {
	clear();
    }

    /**
     * Returns true if a point is already in the tree.
     * Returns false otherwise.
     * 
     * The traversal remains the same.  Start at the root, if the tree
     * is not empty, and compare the x-coordinates of the point passed
     * in and the root.  
     * 
     * If the x-coordinate of the pointToSearch is less
     * than the x-coordinate of the root then go left if possible.
     * 
     * If the x-coordinate of the pointToSearch is greater than or equal to
     * the x-coordinate of the root then go right if possible.
     * 
     * Alternate which coordinate is checked at each level by first 
     * checking x then y then x then y and so on.
     * 
     * If a null is ever reached or the tree is empty a false should be the result.
     * If the point that is passed in is found in the tree, in other words
     * if N is a node in the tree and N.point.equals(pointToSearch) then return true. 
     * 
     * @param pointToSearch The point that is to be determined if it exists in the tree.
     * @return True if a point with the same X and Y values as pointToSearch exists
     * 		False otherwise.
     */
    public boolean contains(Point2D pointToSearch) {
	return false;
    }

    /**
     * Adds a point to the 2D using the following traversal scheme.
     * 
     * If the tree is empty, set root to a new tree node that contains newPoint.
     * Otherwise, set a tree node, current, to root.
     * 		If newPoint.x < current.point.x
     * 			If current.left == null
     * 				Add a new TreeNode with newPoint to current.left
     * 			else 
     * 				Set current to current.left
     * 		If newPoint.x >= current.point.x
     * 			Check that current.point equals newPoint
     * 				if it does then raise the IllegalArgumentException
     * 				Else do nothing
     * 			if current.right == null
     * 				Add a new TreeNode with newPoint to current.right
     * 			else
     * 				Set current to current.right
     * 
     * This should alternate between x then y then x then y.  If the element is added, remember
     * to increment size.
     * 
     * @param newPoint Point to be added to the tree.
     */
    public void add(Point2D newPoint) {
    	
	if(isEmpty()) {
		root = new TwoDTreeNode(newPoint);
	} else{
		TwoDTreeNode temp = root;
		TwoDTreeNode current = null;
		while(temp != null)
		if(current.point.x > newPoint.x) {
			if(current.left == null) {
				
			}else {
				current = current.left;
			} if(newPoint.x )
			
		}
		
	}
    }

    /********************************/
    public void clear() {
	root = null;
	size = 0;
    }

    public int getSize() {
	return size;
    }

    public boolean isEmpty() {
	return size == 0;
    }

    @Override
    public String toString() {
	StringBuilder sb = new StringBuilder();
	buildLevelOrderString(sb);
	return sb.toString();
    }

    private void buildLevelOrderString(StringBuilder sb) {
	if (!isEmpty()) {
	    // Will be used as a queue for level order traversal
	    LinkedList<TwoDTreeNode> q = new LinkedList<>();
	    q.addLast(root);
	    TwoDTreeNode temp;
	    while (!q.isEmpty()) {
		temp = q.removeFirst();
		if (temp.left != null) {
		    q.addLast(temp.left);
		}

		if (temp.right != null) {
		    q.addLast(temp.right);
		}

		sb.append(temp.point);

		if (!q.isEmpty()) {
		    sb.append(", ");
		}
	    }
	}
    }

    private class TwoDTreeNode {
	private TwoDTreeNode left;
	private TwoDTreeNode right;
	private Point2D point;

	public TwoDTreeNode() {
	}

	public TwoDTreeNode(Point2D p) {
	    this.point = p;
	}

	public TwoDTreeNode getLeft() {
	    return left;
	}

	public TwoDTreeNode getRight() {
	    return right;
	}

	public void setLeft(TwoDTreeNode left) {
	    this.left = left;
	}

	public void setRight(TwoDTreeNode right) {
	    this.right = right;
	}

	public int getX() {
	    return point.x;
	}

	public int getY() {
	    return point.y;
	}
    }
}
