package hashpairz;

import java.util.HashSet;

public class hash {

	public static void main(String[] args) {
		HashSet <Integer> numbers = new HashSet<>();
		
		int nums [] = {24, 11, 49, -17, 42, 27, -43, -29, -10, -45};
		
		int diff = 13;
		
		for(int n : nums) {
			numbers.add(n);
			
		}
		
		for(int n : nums) {
			if(numbers.contains(n - diff)) {
				System.out.println(n + ", " + (n - diff));
			}
		}
	}

}
