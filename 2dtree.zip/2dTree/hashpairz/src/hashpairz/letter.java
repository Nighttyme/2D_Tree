package hashpairz;

import java.util.HashMap;
import java.util.Scanner;

public class letter {

	public static void main(String[] args) {
		 Scanner input = new Scanner(System.in);
		 System.out.println("Enter a String: ");
			String letters = input.nextLine();
		HashMap <Character, Integer> words = new HashMap<>();
				
		for (char c : letters.toCharArray()) {
			if(words.containsKey(c)) {
				words.replace(c, words.get(c) + 1);
			}else {
				words.put(c, 1);
			}		    
		    System.out.print(words);
		    input.close();
		}
	}

}
